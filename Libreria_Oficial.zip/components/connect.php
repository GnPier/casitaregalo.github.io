<?php

$db_name = 'mysql:host=localhost;dbname=id21613386_casitaregalo';
$user_name = 'id21613386_casitaregalo';
$user_password = 'Casita-123';

$conn = new PDO($db_name, $user_name, $user_password);

?>
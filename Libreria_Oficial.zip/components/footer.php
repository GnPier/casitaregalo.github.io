<footer class="footer">

   <section class="grid">

      <div class="box">
         <h3>Paginas principales</h3>
         <a href="index.php"> <i class="fas fa-angle-right"></i> Inicio</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> Sobre Nosotros</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Tienda</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contactanos</a>
      </div>

      <div class="box">
         <h3>Links Extras</h3>
         <a href="user_login.php"> <i class="fas fa-angle-right"></i> Iniciar Sesion</a>
         <a href="user_register.php"> <i class="fas fa-angle-right"></i> Registrarse</a>
         <a href="cart.php"> <i class="fas fa-angle-right"></i> Carrito</a>
         <a href="orders.php"> <i class="fas fa-angle-right"></i> Pedidos</a>
      </div>

      <div class="box">
         <h3>Contactanos</h3>
         <a href="tel:1234567890"><i class="fas fa-phone"></i> +51 951 606 717</a>
         <a href="tel:11122233333"><i class="fas fa-phone"></i> +51 921 209 353</a>
         <p></p><i class="fas fa-envelope"></i> CasitaRegalo@gmail.com </p><br>
         <p></p><i class="fas fa-envelope"></i> Piura-Pariñas </p><br>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/denissekarine.saavedraespinoza"><i class="fab fa-facebook-f"></i>facebook</a>
      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>Geampier Atoche , Jair Zevallos Flores , Jair Atoche Espinoza , Cristian Madrid Vite</span> | todos los derechos reservados!</div>

</footer>